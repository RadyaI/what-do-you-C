#include <stdio.h>

void main(){
    int a,b;
    a = 20;
    b = 15;

    a > b ? printf("Nilai a lebih besar") : printf("Nilai b lebih besar");

}
#include <stdio.h>

int main() {
    char arr[] = {'i', 'n', 'd', 'o', 'n', 'e', 's', 'i', 'a'};

    for(int i = 0; i < 9; i++) {
        printf("%c", arr[i]);
    }

    printf("\n");
    return 0;
}

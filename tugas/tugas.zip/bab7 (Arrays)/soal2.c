#include <stdio.h>

int main() {
    char arr[] = {'a', 'i', 'u', 'e', 'o'};

    for(int i = 0; i < 5; i++) {
        printf("%c ", arr[i]);
    }

    return 0;
}

#include <stdio.h>

int main(){
    const float PHI = 3.14;
    const int MAXSIZE = 255;
    const char ROOTDIR = 'C';
    const float MIN_KELVIN = 80.0;
    const float R = 8.314472;
}
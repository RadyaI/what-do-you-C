#include <stdio.h>

int main(){
    int jumlah = 0;
    char jawaban = 'B';
    double suhu_awal = 25.0;
    float radius = 0.0;
    double harga = 10000.0;
    int nilai_hexa = 0x1A;
    int nilai_oktal = 022;

    return 0;
}
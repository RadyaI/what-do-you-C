#include <stdio.h>

int main() {
    for(int i = 0; i <= 100; i += 5) {
        printf("%d\n", i);
    }
    return 0;
}

#include <stdio.h>

int main() {
    for(int i = 0; i < 100; i++) {
        printf("Teknik Informatika YES\n");
    }
    return 0;
}
